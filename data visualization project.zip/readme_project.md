**Titanic Passengers Characteristics on Their Rate of Survival**

**By Agboola, Quam.**

**DATA DESCRIPTION**

  PassengerId   Survived   Pclass   Name                                                  Sex      Age    SibSp   Parch   Ticket             Fare      Cabin   Embarked
  ------------- ---------- -------- ----------------------------------------------------- -------- ------ ------- ------- ------------------ --------- ------- ----------
  1             0          3        Braund, Mr. Owen Harris                               male     22     1       0       A/5 21171          7.25              S
  2             1          1        Cumings, Mrs. John Bradley (Florence Briggs Thayer)   female   38     1       0       PC 17599           71.2833   C85     C
  3             1          3        Heikkinen, Miss. Laina                                female   26     0       0       STON/O2. 3101282   7.925             S
  4             1          1        Futrelle, Mrs. Jacques Heath (Lily May Peel)          female   35     1       0       113803             53.1      C123    S
  5             0          3        Allen, Mr. William Henry                              male     35     0       0       373450             8.05              S
  6             0          3        Moran, Mr. James                                      male     29.7   0       0       330877             8.4583            Q
  7             0          1        McCarthy, Mr. Timothy J                               male     54     0       0       17463              51.8625   E46     S
  8             0          3        Palsson, Master. Gosta Leonard                        male     2      3       1       349909             21.075            S
  9             1          3        Johnson, Mrs. Oscar W (Elisabeth Vilhelmina Berg)     female   27     0       2       347742             11.1333           S
  10            1          2        Nasser, Mrs. Nicholas (Adele Achem)                   female   14     1       0       237736             30.0708           C

**TITANIC DATASET OVERVIEW**

We have 889 passengers that board the titanic, and the attributes of
each passengers include:

\(1\) passengerid = the passengers id

\(2\) survived = whether the passengers survived or not (0-not survived,
1-survived)

\(3\) pclass = passenger ticket class (1-high class, 2-middle class,
3-low class)

\(4\) name, sex, age = the name, gender =, and age of passengers

\(5\) ticket, fare, cabin, embarked = the ticket, the amount paid,
cabin, and in embarks

\(6\) sibsp = the number of siblings and spouse each passengers have on
board

\(7\) parch = the number of parents and children each passengers have on
board

**SUMMARY OF TITANIC DATASET FINDINGS**

In this project, I analyzed data associated with the tragic event of the
sinking Titanic.

In addition, I was particularly interested in finding trends among the
passengers who survived, and how they differed from the passengers who
didn't survive.

Using the titanic dataset, I explore the relationships between each of
the predictor variables with the outcome variable (survived)

[Predictor variables]{.ul}

These are the variables we used in predicting the outcome variable
survived

-   passengerid = the passengers id

-   pclass = passenger ticket class (1-high class, 2-middle class, 3-low
    class)

-   name, sex, age = the name, gender =, and age of passengers

-   ticket, fare, cabin, embarked = the ticket, the amount paid, cabin,
    and in embarks

-   sibsp = the number of siblings and spouse each passengers have on
    board

-   parch = the number of parents and children each passengers have on
    board

[Outcome variable]{.ul}

This is the variable I want to make conclusion on

-   survived = whether the passengers survived or not (0-not survived,
    1-survived)

**Key Insights for Presentation**

In conclusion, we found that all the predictor variables In the titanic
dataset have an association with a passenger surviving or not
